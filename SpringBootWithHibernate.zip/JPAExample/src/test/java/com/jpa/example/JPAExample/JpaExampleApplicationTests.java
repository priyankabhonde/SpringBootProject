package com.jpa.example.JPAExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
