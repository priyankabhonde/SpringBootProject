package com.jpa.example.JPAExample.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class User {
	int id;
	String name;
	String profile;
	String salary;
	
	@Id
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getProfile() {
		return profile;
	}
	public void setProfile(String profile) {
		this.profile = profile;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", profile=" + profile + ", salary=" + salary + "]";
	}
	

}
