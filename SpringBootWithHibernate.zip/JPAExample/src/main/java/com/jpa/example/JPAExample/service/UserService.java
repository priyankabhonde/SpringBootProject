package com.jpa.example.JPAExample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jpa.example.JPAExample.dao.UserDao;
import com.jpa.example.JPAExample.entity.User;

@Service
public class UserService {
	@Autowired
	UserDao d;
	public List<User> GetUser() {
		List<User> list = d.GetUser();
		return list;
	}
	
	public User getsingleuserdata() {
		User u =d.getsingleuserdata();
		return u;
	}

	
	public String InsertUser(List<User> ul) {
		String msg = d.InsertUser(ul);
		return msg;
	}

	public String InsertSingleUser(User u) {
		String msg = d.InsertSingleUser(u);
		return msg;
	}

	public List<User> getUseByID(int id) {
		List<User> list = d.getUseByID(id);
		return list;
	}
	
	public String insertdata(User u) {
		String list = d.insertdata(u);
		return list;
	}
	public String insertinfo(List<User> u) {
		String list = d.insertinfo(u);
		return list;
	}


	public List<User> getlistofuser() {
		List<User> list = d.getlistofuser();
		return list;
	}
	
	public List<User> greatersalary() {
		List<User> list = d.greatersalary();
		return list;
	}
	
	public List<User> lesssalary() {
		List<User> list = d.lesssalary();
		return list;
}
	public List<User> betweensal() {
		List<User> list = d.betweensal();
		return list;
	
}
	public List<User> And() {
		List<User> list = d.And();
		return list;
	}
	public List<User>  OR() {
		List<User> list = d.OR();
		return list;
	}
	public List<User> notequal() {
		List<User> list = d.notequal();
		return list;
	}
	public List<User> equal() {
		List<User> li = d.equal();
		return li;
	}
	public List<User> greatereq() {
		List<User> list = d.greatereq();
		return list;
	}
	public List<User> lessthaneq() {
		List<User> list = d.lessthaneq();
		return list;
}

	public String deleteinfo(int id) {
		String list = d.deleteinfo(id);
		return list;
	}
	public List<User>  nullsalary() {
		List<User> list = d.nullsalary();
		return list;
	}
	public String updateinfo(User u) {
		String list = d.updateinfo(u);
		return list;
	}
	public List<User>  getname() {
		List<User> list = d.getname();
		return list;
	}
	public List<User> byname(String name) {
		List<User> list = d.byname(name);
		return list;
	}
	public List<User> byprofile(String profile) {
		List<User> li = d.byprofile(profile);
		return li;
	}


}
