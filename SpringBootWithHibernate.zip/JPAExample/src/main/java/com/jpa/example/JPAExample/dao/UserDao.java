package com.jpa.example.JPAExample.dao;


import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jpa.example.JPAExample.entity.User;

@Repository
public class UserDao {
	@Autowired
	SessionFactory sf;
	public List<User> GetUser() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		List<User> list =  criteria.list();
		System.out.println(list);
		for (User user : list) {
			System.out.println(user);
			
		}
		return list;
	}
	public User getsingleuserdata() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		User u = session.get(User.class, 6);
		System.out.println(u);
		session.close();
		return u;
	}
	public String InsertUser(List<User> ul) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for (User user : ul) {
			session.save(user);
			//System.out.println(user);
			
		}
		tr.commit();
		session.close();
		
		return "UserInsertedSuccessfully";
	}
	public String InsertSingleUser(User u) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(u);
		tr.commit();
		session.close();
		System.out.println(u);
		
		return "UserDataSuccessfully";
	}
	
	public List<User> getUseByID(int id) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("id", id));
		List<User> list = criteria.list();
		for (User user : list) {
			System.out.println(user);
		}
		 return list;
	}
	
	
	public String insertdata( User u) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(u);
		
		session.close();
		tr.commit();
		return "data inserted";	
	}
	public String insertinfo(List<User> u) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		for(User data:u)
		{
		session.save(data);
		}
		session.close();
		tr.commit();
		return "insertinfo";
	}
	

	
	public List<User>  getlistofuser() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	
	public List<User> greatersalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.gt("salary", "70000"));
		List<User> list = criteria.list();
		
		
		session.close();
		return list;
	}
	
	public List<User> lesssalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.lt("salary", "80000"));
		List<User> list= criteria.list();
		
		session.close();
		return list;
	}
	
	public List<User> betweensal() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.between("salary", "50000", "80000"));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	
	public List<User> And() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.and(Restrictions.eq("name", "%i"),(Restrictions.eq("name", "%i"))));
		List<User> list = criteria.list();
		for (User user : list) {
			System.out.println(user);
			
		}
		
		session.close();
		return list;		
				
	}
	
	
	public List<User> OR() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.or(Restrictions.like("name", "%i"),(Restrictions.eq("salary", "%i"))));
		List<User> list = criteria.list();
		session.close();
		return list;
		
	}
	
	public List<User> notequal() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class) ;
		criteria.add(Restrictions.ne("salary", "20000"));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	public List <User> equal() {
		Session session = sf.openSession();
	Criteria criteria =	session.createCriteria(User.class);
	criteria.add(Restrictions.eq("profile", "developer"));
	List <User>list = criteria.list();
	
	session.close();
	return list;
	
	}
	public List<User> greatereq() {
		Session session = sf.openSession();
		 Criteria criteria =session.createCriteria(User.class);
		criteria.add(Restrictions.ge("salary", "20000"));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	public List<User> lessthaneq() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.le("salary", "20000"));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}

	public String deleteinfo(int id) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		Transaction tr = session.beginTransaction();
		User u = session.get(User.class, id);
		session.delete(u);
		
		tr.commit();
		session.close();
		return"Data deleted";
	}
	public List<User> nullsalary() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.ilike("salary","25000"));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	public String updateinfo(User u) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		Transaction tr = session.beginTransaction();
		session.update(u);
		
		tr.commit();
		return "data successfully updatd";	
	}
	public List<User> getname() {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class);
		criteria.add(Restrictions.eq("name", "%l"));
	    List<User> list = criteria.list();
	    session.close();
	    return list;
	}
	
	public List<User> byname(String name) {
		Session session = sf.openSession();
		Criteria criteria = session.createCriteria(User.class) ;
		criteria.add(Restrictions.eq("name", name));
		List<User> list = criteria.list();
		
		session.close();
		return list;
	}
	
	public List<User> byprofile(String profile) {
		Session session = sf.openSession();
	Criteria criteria= 	session.createCriteria(User.class);
	criteria.add(Restrictions.eq("profile", profile));
	List<User> list = criteria.list();
	
	session.close();
	return list;
	}

}
