package com.jpa.example.JPAExample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.jpa.example.JPAExample.entity.User;
import com.jpa.example.JPAExample.service.UserService;

@RestController
public class UserController {
	
	@Autowired
	UserService s;
	
	@GetMapping("/get")
	public List<User> GetUser() {
		List<User> list = s.GetUser();
		return list;
	}
	
	@GetMapping("/single")
	public User getsingleuserdata() {
		User u = s.getsingleuserdata();
		return u;
	}
	
	@PostMapping("/post")
	public String InsertUser(@RequestBody List<User> ul) {
		String msg = s.InsertUser(ul);
		return msg;
	}
	
	@PostMapping("/singlepost")
	public void InsertSingleUser(@RequestBody User u) {
		String msg = s.InsertSingleUser(u);
	}
	
	@GetMapping("/byid/{id}")
	public List<User> getUseByID(@PathVariable int id) {
		List<User> list = s.getUseByID(id);
		return list;
	}
	
	@PostMapping("/insert")
	public String insertdata(@RequestBody User u) {
		String list = s.insertdata(u);
		return list;
	}
	@PostMapping("/insertinf")
	public String insertinfo(@RequestBody List<User> u) {
		String list = s.insertinfo(u);
		return list;
	}

	@GetMapping("/inf")
	public List<User> getlistofuser() {
		List<User> list = s.getlistofuser();
		return list;
}
	@GetMapping("/grt")
	public List<User> greatersalary() {
		List<User> list = s.greatersalary();
		return list;
}
	@GetMapping("/lt")
	public List<User> lesssalary() {
		List<User> list = s.lesssalary();
		return list;
	}
	@GetMapping("/bt")
	public List<User> betweensal() {
		List<User> list = s.betweensal();
		return list;
}
	@GetMapping("/ad")
	public List<User>  And() {
		List<User> list = s.And();
		return list;
	}
	@GetMapping("/oo")
	public List<User> OR() {
		List<User> list = s.OR();
		return list;
	}
	@GetMapping("/ne")
	public List<User> notequal() {
		List<User> list = s.notequal();
		return list;
	}
	@GetMapping("/ee")
	public List<User> equal() {
		List<User> list = s.equal();
		return list;
	}
	@GetMapping("/ge")
	public List<User>  greatereq() {
		List<User> list = s.greatereq();
		return list;
	}
	
	@GetMapping("/le")
	public List<User> lessthaneq() {
		List<User> li = s.lessthaneq();
		return li;
	}

	@DeleteMapping("del/{id}")
	public String  deleteinfo( @PathVariable int id) {
		String list = s.deleteinfo(id);
		return list;
	}
	@GetMapping("/ntn")
	public List<User> nullsalary() {
		List<User> list = s.nullsalary();
		return list;
	}
	@PutMapping("/up")
	public String updateinfo(@RequestBody  User u) {
		String list = s.updateinfo(u);
		return list;
	}
	@GetMapping("/nam")
	public List<User> getname() {
		List<User> list = s.getname();
		return list;
	}
	@GetMapping("/n/{name}")
	public List<User> byname( @PathVariable String name) {
		List<User> list = s.byname(name);
		return list;
	}
	@GetMapping("/prf/{profile}")
	public List<User> bydept( @PathVariable  String profile) {
		List<User> li = s.byprofile(profile);
		return li;
	}
	

}
